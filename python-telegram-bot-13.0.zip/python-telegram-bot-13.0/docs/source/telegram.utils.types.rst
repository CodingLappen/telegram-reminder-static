telegram.utils.types Module
===========================

.. automodule:: telegram.utils.types
    :members:
    :show-inheritance:
