telegram.InlineQueryResultCachedPhoto
=====================================

.. autoclass:: telegram.InlineQueryResultCachedPhoto
    :members:
    :show-inheritance:
