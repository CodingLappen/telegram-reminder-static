telegram.DataCredentials
========================

.. autoclass:: telegram.DataCredentials
    :members:
    :show-inheritance:
