telegram.ext.DispatcherHandlerStop
==================================

.. autoclass:: telegram.ext.DispatcherHandlerStop
    :members:
    :show-inheritance:
