telegram.InlineQueryResultMpeg4Gif
==================================

.. autoclass:: telegram.InlineQueryResultMpeg4Gif
    :members:
    :show-inheritance:
