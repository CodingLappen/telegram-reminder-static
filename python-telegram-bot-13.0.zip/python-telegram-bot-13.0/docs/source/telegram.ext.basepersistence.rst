telegram.ext.BasePersistence
============================

.. autoclass:: telegram.ext.BasePersistence
    :members:
    :show-inheritance:
