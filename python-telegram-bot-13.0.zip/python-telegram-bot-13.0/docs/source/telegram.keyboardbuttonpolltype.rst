telegram.KeyboardButtonPollType
===============================

.. autoclass:: telegram.KeyboardButtonPollType
    :members:
    :show-inheritance:
