telegram.ext.RegexHandler
=========================

.. autoclass:: telegram.ext.RegexHandler
    :members:
    :show-inheritance:
