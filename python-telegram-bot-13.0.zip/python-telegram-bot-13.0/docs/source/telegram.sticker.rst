telegram.Sticker
================

.. autoclass:: telegram.Sticker
    :members:
    :show-inheritance:
